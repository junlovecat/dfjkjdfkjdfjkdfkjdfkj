from setuptools import setup
setup(
    name='tensorflower',
    version='1.0.0',
    description='tensorflow helper',
    author='Airbus_A380',
    author_email='junlovecatdog@naver.com',
    url='dse.kro.kr',
    py_modules=['confidence','label'],
)